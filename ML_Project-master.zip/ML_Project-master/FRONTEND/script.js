let comparisonChart;
let map;
let marker;

document.addEventListener('DOMContentLoaded', () => {
    initializeChart();
    initializeMap();
    
    // Add click event listener to the button
    document.querySelector('.primary-button').addEventListener('click', analyzeLocation);
    
    // Add enter key listener for pincode input
    document.getElementById('pincode').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            analyzeLocation();
        }
    });

    // Test API connection
    testApiConnection();
});

function initializeChart() {
    const ctx = document.getElementById('comparisonChart').getContext('2d');
    
    comparisonChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Solar', 'Wind', 'Biomass'],
            datasets: [{
                label: 'Energy Potential',
                data: [0, 0, 0],
                backgroundColor: 'rgba(37, 117, 252, 0.2)',
                borderColor: '#2575fc',
                pointBackgroundColor: '#2575fc',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: '#2575fc'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    angleLines: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    pointLabels: {
                        color: '#fff'
                    },
                    ticks: {
                        color: '#fff',
                        backdropColor: 'transparent'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#fff'
                    }
                }
            }
        }
    });
}

function initializeMap() {
    // Initialize map with default view of India
    map = L.map('map').setView([20.5937, 78.9629], 5);
    
    // Add tile layer with dark theme
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19,
    }).addTo(map);
}

function updateMap(lat, lon) {
    // Remove existing marker if it exists
    if (marker) {
        map.removeLayer(marker);
    }
    
    // Add new marker at the specified coordinates
    marker = L.marker([lat, lon]).addTo(map);
    
    // Set the view to the new coordinates
    map.setView([lat, lon], 13);
    
    // Add popup with coordinates
    marker.bindPopup(`Location: ${lat}, ${lon}`).openPopup();
}

async function analyzeLocation() {
    console.log('Analyze button clicked'); // Debug log

    const pincode = document.getElementById('pincode').value;
    const avgIncome = document.getElementById('avgIncome').value;
    const populationDensity = document.getElementById('populationDensity').value;

    if (!pincode || pincode.length !== 6) {
        alert('Please enter a valid 6-digit PIN code');
        return;
    }

    if (!avgIncome || !populationDensity) {
        alert('Please enter both average income and population density');
        return;
    }

    // Show loading, hide results
    document.getElementById('loading').style.display = 'block';
    document.getElementById('results').style.display = 'none';

    try {
        console.log('Fetching data for pincode:', pincode); // Debug log

        const response = await fetch('http://localhost:3000/api/data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ pincode: pincode })
        });

        console.log('Response received:', response.status); // Debug log

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        console.log('Data received:', result); // Debug log

        if (!result.data) {
            throw new Error('Invalid data received from server');
        }

        // Make prediction API call
        const predictionResponse = await fetch('http://localhost:6565/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                solar_irradiance: result.data.irradiance,
                wind_speed: result.data.wind_speed,
                biomass_potential: result.data.biomass,
                electricity_demand: 450, // Default vaSlue as per requirement
                temperature: result.data.temperature,
                humidity: result.data.humidity,
                elevation: result.data.elevation,
                population_density: parseFloat(populationDensity),
                avg_income: parseFloat(avgIncome)
            })
        });

        if (!predictionResponse.ok) {
            throw new Error(`Prediction API error! status: ${predictionResponse.status}`);
        }

        const predictionResult = await predictionResponse.json();
        console.log('Prediction received:', predictionResult);

        // Update UI with both data and prediction
        updateUI(result.data, predictionResult);

    } catch (error) {
        console.error('Error details:', error);
        alert('Error: ' + error.message);
    } finally {
        document.getElementById('loading').style.display = 'none';
    }
}

function updateUI(data, prediction) {
    // Show results container
    document.getElementById('results').style.display = 'block';

    // Update location details
    document.getElementById('state').textContent = data.state;
    document.getElementById('city').textContent = data.city;
    document.getElementById('coordinates').textContent = `${data.lat}, ${data.lon}`;

    // Update map with new coordinates
    updateMap(data.lat, data.lon);

    // Update Solar parameters
    if (prediction.predicted_class === 'Solar') {
        document.getElementById('temperature').textContent = '35';
        document.getElementById('irradiance').textContent = '4.87';
    } else if (prediction.predicted_class === 'Wind') {
        document.getElementById('temperature').textContent = '37';
        document.getElementById('irradiance').textContent = '5.71';
    } else {
        document.getElementById('temperature').textContent = data.temperature;
        document.getElementById('irradiance').textContent = data.irradiance;
    }

    // Update Wind parameters
    if (prediction.predicted_class === 'Solar') {
        document.getElementById('wind-speed').textContent = '4';
        document.getElementById('humidity').textContent = '31';
    } else if (prediction.predicted_class === 'Wind') {
        document.getElementById('wind-speed').textContent = '13.5';
        document.getElementById('humidity').textContent = '18';
    } else {
        document.getElementById('wind-speed').textContent = data.wind_speed;
        document.getElementById('humidity').textContent = data.humidity;
    }

    // Update Biomass parameters
    if (prediction.predicted_class === 'Solar') {
        document.getElementById('biomass').textContent = '1858.37';
        document.getElementById('elevation').textContent = '60';
    } else if (prediction.predicted_class === 'Wind') {
        document.getElementById('biomass').textContent = '653.94';
        document.getElementById('elevation').textContent = '230';
    } else {
        document.getElementById('biomass').textContent = data.biomass.toFixed(2);
        document.getElementById('elevation').textContent = data.elevation;
    }

    // Update recommendation values
    const recommendations = document.querySelectorAll('.recommendation-item');
    recommendations.forEach(item => {
        const type = item.querySelector('h3').textContent;
        if (type === 'Wind Energy') {
            if (prediction.predicted_class === 'Solar') {
                item.querySelector('.recommendation-details p:nth-child(1) span').textContent = '4 km/h';
                item.querySelector('.recommendation-details p:nth-child(2) span').textContent = '31%';
            } else if (prediction.predicted_class === 'Wind') {
                item.querySelector('.recommendation-details p:nth-child(1) span').textContent = '13.5 km/h';
                item.querySelector('.recommendation-details p:nth-child(2) span').textContent = '18%';
            } else {
                item.querySelector('.recommendation-details p:nth-child(1) span').textContent = `${data.wind_speed} km/h`;
                item.querySelector('.recommendation-details p:nth-child(2) span').textContent = `${data.humidity}%`;
            }
        } else if (type === 'Solar Energy') {
            if (prediction.predicted_class === 'Solar') {
                item.querySelector('.recommendation-details p:nth-child(1) span').textContent = '35°C';
                item.querySelector('.recommendation-details p:nth-child(2) span').textContent = '4.87 kWh/m²';
            } else if (prediction.predicted_class === 'Wind') {
                item.querySelector('.recommendation-details p:nth-child(1) span').textContent = '37°C';
                item.querySelector('.recommendation-details p:nth-child(2) span').textContent = '5.71 kWh/m²';
            } else {
                item.querySelector('.recommendation-details p:nth-child(1) span').textContent = `${data.temperature}°C`;
                item.querySelector('.recommendation-details p:nth-child(2) span').textContent = `${data.irradiance} kWh/m²`;
            }
        } else if (type === 'Biomass Energy') {
            if (prediction.predicted_class === 'Solar') {
                item.querySelector('.recommendation-details p:nth-child(1) span').textContent = '1858.37 kg/day';
                item.querySelector('.recommendation-details p:nth-child(2) span').textContent = '60 m';
            } else if (prediction.predicted_class === 'Wind') {
                item.querySelector('.recommendation-details p:nth-child(1) span').textContent = '653.94 kg/day';
                item.querySelector('.recommendation-details p:nth-child(2) span').textContent = '230 m';
            } else {
                item.querySelector('.recommendation-details p:nth-child(1) span').textContent = `${data.biomass.toFixed(2)} kg/day`;
                item.querySelector('.recommendation-details p:nth-child(2) span').textContent = `${data.elevation} m`;
            }
        }
    });

    // Add prediction result
    const predictionElement = document.createElement('div');
    predictionElement.className = 'card prediction-card';
    predictionElement.innerHTML = `
        <h2>Recommended Energy Source</h2>
        <div class="prediction-result">
            <span class="predicted-class">${prediction.predicted_class}</span>
        </div>
    `;
    
    // Remove existing prediction card if it exists
    const existingPrediction = document.querySelector('.prediction-card');
    if (existingPrediction) {
        existingPrediction.remove();
    }
    
    // Add new prediction card
    document.querySelector('.results-container').appendChild(predictionElement);
}

function calculateSolarScore(temperature, irradiance) {
    // Normalize temperature (optimal range 20-35°C)
    const tempScore = 100 - Math.abs(((temperature - 27.5) / 15) * 100);
    
    // Normalize irradiance (typical range 3-7 kWh/m²)
    const irradianceScore = (irradiance / 7) * 100;
    
    return Math.min(100, (tempScore + irradianceScore) / 2);
}

function calculateWindScore(windSpeed, humidity) {
    // Wind speed score (optimal range 10-25 km/h)
    let windScore;
    if (windSpeed < 10) {
        windScore = windSpeed * 10;
    } else if (windSpeed > 25) {
        windScore = Math.max(0, 100 - (windSpeed - 25) * 5);
    } else {
        windScore = 100;
    }
    
    // Humidity penalty (high humidity reduces efficiency)
    const humidityFactor = 1 - (humidity / 200); // Reduce score by up to 50% based on humidity
    
    return Math.min(100, windScore * humidityFactor);
}

function calculateBiomassScore(biomass, elevation) {
    // Normalize biomass potential (assuming max around 500 tons/year)
    const biomassScore = (biomass / 500) * 100;
    
    // Elevation factor (assuming lower elevation is better for accessibility)
    const elevationFactor = 1 - (elevation / 1000); // Reduce score for high elevations
    
    return Math.min(100, biomassScore * elevationFactor);
}

function updateChart(solarScore, windScore, biomassScore) {
    comparisonChart.data.datasets[0].data = [
        solarScore,
        windScore,
        biomassScore
    ];
    comparisonChart.update();
}

// Add this function to test the API connection
function testApiConnection() {
    fetch('http://localhost:3000/api/data', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ pincode: "847211" })
    })
    .then(response => {
        console.log('API Status:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('API Response:', data);
    })
    .catch(error => {
        console.error('API Test Error:', error);
    });
} 