from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import pickle

app = Flask(__name__)
CORS(app)  # 👈 Enable CORS for all routes

class_mapping = {
    0: "Biomass",
    1: "Solar",
    2: "Wind"
}

# Load model, encoder, and scaler
with open("xgboost_energy_model.pkl", "rb") as file:
    model, encoder, scaler = pickle.load(file)

@app.route("/predict", methods=["POST"])
def predict_energy():
    try:
        data = request.json

        # Prepare input DataFrame
        input_data = pd.DataFrame([{
            "solar_irradiance": data["solar_irradiance"],
            "wind_speed": data["wind_speed"],
            "biomass_potential": data["biomass_potential"],
            "electricity_demand": data["electricity_demand"],
            "temperature": data["temperature"],
            "humidity": data["humidity"],
            "elevation": data["elevation"],
            "population_density": data["population_density"],
            "avg_income": data["avg_income"]
        }])

        # Scale input features
        input_scaled = scaler.transform(input_data)

        # Predict and convert to label
        prediction = model.predict(input_scaled)
        predicted_label = encoder.inverse_transform(prediction)[0]

        return jsonify({
            "predicted_class": class_mapping.get(predicted_label)
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, port=6565)
