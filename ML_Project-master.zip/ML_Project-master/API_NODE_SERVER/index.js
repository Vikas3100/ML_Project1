process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';

const express = require('express');
const app = express();
const PORT = 3000;

const cors = require('cors'); // Import CORS


app.use(express.json()); // JSON middleware

app.use(cors());

// Helper: Validate JSON response
const safeFetchJSON = async (url) => {
    const res = await fetch(url);
    const text = await res.text();
    try {
        return JSON.parse(text);
    } catch {
        throw new Error(`Invalid JSON from URL: ${url}`);
    }
};

// Get location details
const getLocationDetails = async (pincode) => {
    const locationIQUrl = `https://us1.locationiq.com/v1/search.php?key=pk.dda36681750f72cb403e58eda4f08c3c&q=${pincode}&format=json`;
    const postalPinUrl = `https://api.postalpincode.in/pincode/${pincode}`;

    const result = await safeFetchJSON(locationIQUrl);
    const result1 = await safeFetchJSON(postalPinUrl);

    if (!result || result.length === 0) throw new Error("LocationIQ returned no results.");
    if (!result1 || result1[0].Status !== "Success") throw new Error("PostalPincode returned no results.");

    return {
        lat: result[0].lat,
        lon: result[0].lon,
        state: result1[0].PostOffice[0].State,
        city: result1[0].PostOffice[0].District
    };
};

// Get elevation
const getElevation = async (lat, lon) => {
    const url = `https://api.open-elevation.com/api/v1/lookup?locations=${lat},${lon}`;
    const result = await safeFetchJSON(url);

    if (!result || !result.results || !result.results.length) throw new Error("Elevation API returned no results.");

    return {
        elevation: result.results[0].elevation
    };
};

// Get solar irradiance
const getSolarIrradiance = async (lat, lon) => {
    const url = `https://re.jrc.ec.europa.eu/api/v5_2/PVcalc?lat=${lat}&lon=${lon}&peakpower=1&loss=14&outputformat=json`;
    const result = await safeFetchJSON(url);

    const irradiance = result.outputs?.totals?.fixed?.["H(i)_d"];
    if (irradiance === undefined) throw new Error("Solar irradiance H(i)_d not found.");

    return { irradiance };
};

// State-wise biomass values
const stateAreas = {
    "Andaman & Nicobar": 43.74129201,
    "Andhra Pradesh": 287.3455253,
    "Arunachal Pradesh": 5.686020128,
    "Assam": 88.75345924,
    "Bihar": 232.2966922,
    "Chandigarh": 26.67627974,
    "Chhattisgarh": 53.7399068,
    "Dadra & Nagar Haveli, and Daman & Diu": 55.24886981,
    "Goa": 171.2513784,
    "Gujarat": 303.8529249,
    "Haryana": 675.9151733,
    "Himachal Pradesh": 28.15855501,
    "Jammu & Kashmir": 32.17838755,
    "Jharkhand": 41.30416403,
    "Karnataka": 200.6822067,
    "Kerala": 425.9500973,
    "Madhya Pradesh": 177.121583,
    "Maharashtra": 191.370281,
    "Manipur": 59.50164154,
    "Meghalaya": 68.56338754,
    "Mizoram": 2.976126656,
    "Nagaland": 72.43029844,
    "Odisha": 39.19549987,
    "Puducherry": 216.2038493,
    "Punjab": 1210.469081,
    "Rajasthan": 81.74212309,
    "Sikkim": 15.44377693,
    "Tamil Nadu": 257.3646278,
    "Telangana": 336.402774,
    "Tripura": 66.56716847,
    "Uttar Pradesh": 245.6335503,
    "Uttarakhand": 37.05184518,
    "West Bengal": 502.4714087
};

// Get weather data
const getOthers = async (city) => {
    const url = `http://api.weatherstack.com/current?access_key=d67751959ff192c16ca290784444b527&query=${city}`;
    const result = await safeFetchJSON(url);

    if (!result.current) throw new Error("Weather API returned no 'current' field.");

    return {
        wind_speed: result.current.wind_speed*0.5,
        humidity: result.current.humidity,
        temperature: result.current.temperature
    };
};

// Get biomass
const getBiomass = async (state) => {
    const biomass = stateAreas[state]*8;
    if (!biomass) throw new Error(`Biomass value not found for state: ${state}`);
    return { biomass };
};

// Aggregate all data
const getAllData = async (pincode) => {
    const { lat, lon, state, city } = await getLocationDetails(pincode);
    const { wind_speed, humidity, temperature } = await getOthers(city);
    const { biomass } = await getBiomass(state);
    const { irradiance } = await getSolarIrradiance(lat, lon);
    const { elevation } = await getElevation(lat, lon);

    return {
        lat,
        lon,
        state,
        city,
        wind_speed,
        humidity,
        temperature,
        biomass,
        irradiance,
        elevation
    };
};

// POST API endpoint
app.post('/api/data', async (req, res) => {
    const { pincode } = req.body;

    if (!pincode) {
        return res.status(400).json({ error: "Pincode is required in the request body." });
    }

    try {
        const data = await getAllData(pincode);
        res.status(200).json({ data });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
